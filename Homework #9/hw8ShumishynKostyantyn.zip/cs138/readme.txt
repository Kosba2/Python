This is a sample repository for the CS138 Programming with Python class.  The reason we are using this is that Mercurial is written in Python.  In addition, I like to introduce students to version control systems as it is used extensively in industry
and is good to learn.  While Git seems to be the preferred choice for DVCS systems I would say that Mercurial is second and is 
much easier to use than Git.

Prof. Lewis